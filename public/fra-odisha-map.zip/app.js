// FRA Categories Data
const fraData = {
    "Very High Potential": {
        "districts": ["Kandhamal", "Mayurbhanj", "Rayagada", "Keonjhar", "Koraput"],
        "description": "High tribal population, significant forest cover, active CFR recognition",
        "cfrPotential": "> 70%",
        "color": "#27ae60"
    },
    "High Potential": {
        "districts": ["Kalahandi", "Sundargarh", "Ganjam", "Angul", "Balangir"],
        "description": "Moderate to high tribal population, good forest cover", 
        "cfrPotential": "50-70%",
        "color": "#2ecc71"
    },
    "Moderate Potential": {
        "districts": ["Sambalpur", "Dhenkanal", "Nawarangpur", "Malkangiri", "Gajapati"],
        "description": "Moderate tribal population and forest cover",
        "cfrPotential": "30-50%", 
        "color": "#f39c12"
    },
    "Low Potential": {
        "districts": ["Boudh", "Debagarh", "Jharsuguda", "Bargarh", "Nuapada"],
        "description": "Lower tribal population or forest cover",
        "cfrPotential": "10-30%",
        "color": "#e74c3c"
    },
    "Very Low Potential": {
        "districts": ["Puri", "Jagatsinghpur", "Khordha", "Cuttack", "Bhadrak", "Balasore", "Jajpur", "Kendrapara", "Nayagarh", "Subarnapur"],
        "description": "Coastal areas, urban centers, minimal forest cover",
        "cfrPotential": "< 10%",
        "color": "#95a5a6"
    }
};

const indianStates = [
    "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", 
    "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala", 
    "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", 
    "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", 
    "Uttar Pradesh", "Uttarakhand", "West Bengal", "Andaman & Nicobar Islands", 
    "Chandigarh", "Dadra & Nagar Haveli", "Delhi", "Jammu & Kashmir", "Ladakh", 
    "Lakshadweep", "Puducherry"
];

// Simplified GeoJSON data for Odisha districts
const odishaDistricts = {
    "type": "FeatureCollection",
    "features": [
        // Very High Potential Districts
        {"type": "Feature", "properties": {"name": "Kandhamal"}, "geometry": {"type": "Polygon", "coordinates": [[[83.8, 20.5], [84.2, 20.5], [84.2, 20.1], [83.8, 20.1], [83.8, 20.5]]]}},
        {"type": "Feature", "properties": {"name": "Mayurbhanj"}, "geometry": {"type": "Polygon", "coordinates": [[[86.5, 22.0], [87.5, 22.0], [87.5, 21.0], [86.5, 21.0], [86.5, 22.0]]]}},
        {"type": "Feature", "properties": {"name": "Rayagada"}, "geometry": {"type": "Polygon", "coordinates": [[[83.2, 19.5], [83.8, 19.5], [83.8, 19.0], [83.2, 19.0], [83.2, 19.5]]]}},
        {"type": "Feature", "properties": {"name": "Keonjhar"}, "geometry": {"type": "Polygon", "coordinates": [[[85.5, 21.8], [86.2, 21.8], [86.2, 21.2], [85.5, 21.2], [85.5, 21.8]]]}},
        {"type": "Feature", "properties": {"name": "Koraput"}, "geometry": {"type": "Polygon", "coordinates": [[[82.5, 18.8], [83.2, 18.8], [83.2, 18.2], [82.5, 18.2], [82.5, 18.8]]]}},
        
        // High Potential Districts
        {"type": "Feature", "properties": {"name": "Kalahandi"}, "geometry": {"type": "Polygon", "coordinates": [[[82.8, 20.2], [83.5, 20.2], [83.5, 19.5], [82.8, 19.5], [82.8, 20.2]]]}},
        {"type": "Feature", "properties": {"name": "Sundargarh"}, "geometry": {"type": "Polygon", "coordinates": [[[83.8, 22.5], [85.0, 22.5], [85.0, 21.5], [83.8, 21.5], [83.8, 22.5]]]}},
        {"type": "Feature", "properties": {"name": "Ganjam"}, "geometry": {"type": "Polygon", "coordinates": [[[84.5, 19.5], [85.2, 19.5], [85.2, 18.8], [84.5, 18.8], [84.5, 19.5]]]}},
        {"type": "Feature", "properties": {"name": "Angul"}, "geometry": {"type": "Polygon", "coordinates": [[[84.8, 21.0], [85.5, 21.0], [85.5, 20.5], [84.8, 20.5], [84.8, 21.0]]]}},
        {"type": "Feature", "properties": {"name": "Balangir"}, "geometry": {"type": "Polygon", "coordinates": [[[82.8, 21.0], [83.5, 21.0], [83.5, 20.2], [82.8, 20.2], [82.8, 21.0]]]}},
        
        // Moderate Potential Districts
        {"type": "Feature", "properties": {"name": "Sambalpur"}, "geometry": {"type": "Polygon", "coordinates": [[[83.5, 21.8], [84.2, 21.8], [84.2, 21.2], [83.5, 21.2], [83.5, 21.8]]]}},
        {"type": "Feature", "properties": {"name": "Dhenkanal"}, "geometry": {"type": "Polygon", "coordinates": [[[85.2, 21.2], [85.8, 21.2], [85.8, 20.5], [85.2, 20.5], [85.2, 21.2]]]}},
        {"type": "Feature", "properties": {"name": "Nawarangpur"}, "geometry": {"type": "Polygon", "coordinates": [[[82.2, 19.2], [82.8, 19.2], [82.8, 18.5], [82.2, 18.5], [82.2, 19.2]]]}},
        {"type": "Feature", "properties": {"name": "Malkangiri"}, "geometry": {"type": "Polygon", "coordinates": [[[81.5, 18.5], [82.2, 18.5], [82.2, 17.8], [81.5, 17.8], [81.5, 18.5]]]}},
        {"type": "Feature", "properties": {"name": "Gajapati"}, "geometry": {"type": "Polygon", "coordinates": [[[84.0, 19.0], [84.5, 19.0], [84.5, 18.5], [84.0, 18.5], [84.0, 19.0]]]}},
        
        // Low Potential Districts
        {"type": "Feature", "properties": {"name": "Boudh"}, "geometry": {"type": "Polygon", "coordinates": [[[83.8, 20.8], [84.2, 20.8], [84.2, 20.3], [83.8, 20.3], [83.8, 20.8]]]}},
        {"type": "Feature", "properties": {"name": "Debagarh"}, "geometry": {"type": "Polygon", "coordinates": [[[84.2, 21.8], [84.8, 21.8], [84.8, 21.2], [84.2, 21.2], [84.2, 21.8]]]}},
        {"type": "Feature", "properties": {"name": "Jharsuguda"}, "geometry": {"type": "Polygon", "coordinates": [[[83.8, 22.0], [84.2, 22.0], [84.2, 21.5], [83.8, 21.5], [83.8, 22.0]]]}},
        {"type": "Feature", "properties": {"name": "Bargarh"}, "geometry": {"type": "Polygon", "coordinates": [[[83.2, 21.5], [83.8, 21.5], [83.8, 21.0], [83.2, 21.0], [83.2, 21.5]]]}},
        {"type": "Feature", "properties": {"name": "Nuapada"}, "geometry": {"type": "Polygon", "coordinates": [[[82.2, 20.8], [82.8, 20.8], [82.8, 20.2], [82.2, 20.2], [82.2, 20.8]]]}},
        
        // Very Low Potential Districts
        {"type": "Feature", "properties": {"name": "Puri"}, "geometry": {"type": "Polygon", "coordinates": [[[85.2, 20.0], [85.8, 20.0], [85.8, 19.5], [85.2, 19.5], [85.2, 20.0]]]}},
        {"type": "Feature", "properties": {"name": "Jagatsinghpur"}, "geometry": {"type": "Polygon", "coordinates": [[[86.0, 20.5], [86.5, 20.5], [86.5, 20.0], [86.0, 20.0], [86.0, 20.5]]]}},
        {"type": "Feature", "properties": {"name": "Khordha"}, "geometry": {"type": "Polygon", "coordinates": [[[85.2, 20.5], [85.8, 20.5], [85.8, 20.0], [85.2, 20.0], [85.2, 20.5]]]}},
        {"type": "Feature", "properties": {"name": "Cuttack"}, "geometry": {"type": "Polygon", "coordinates": [[[85.5, 21.0], [86.0, 21.0], [86.0, 20.3], [85.5, 20.3], [85.5, 21.0]]]}},
        {"type": "Feature", "properties": {"name": "Bhadrak"}, "geometry": {"type": "Polygon", "coordinates": [[[86.2, 21.2], [86.8, 21.2], [86.8, 20.8], [86.2, 20.8], [86.2, 21.2]]]}},
        {"type": "Feature", "properties": {"name": "Balasore"}, "geometry": {"type": "Polygon", "coordinates": [[[86.5, 21.8], [87.2, 21.8], [87.2, 21.2], [86.5, 21.2], [86.5, 21.8]]]}},
        {"type": "Feature", "properties": {"name": "Jajpur"}, "geometry": {"type": "Polygon", "coordinates": [[[85.8, 21.2], [86.5, 21.2], [86.5, 20.5], [85.8, 20.5], [85.8, 21.2]]]}},
        {"type": "Feature", "properties": {"name": "Kendrapara"}, "geometry": {"type": "Polygon", "coordinates": [[[86.2, 20.8], [86.8, 20.8], [86.8, 20.2], [86.2, 20.2], [86.2, 20.8]]]}},
        {"type": "Feature", "properties": {"name": "Nayagarh"}, "geometry": {"type": "Polygon", "coordinates": [[[84.8, 20.5], [85.2, 20.5], [85.2, 20.0], [84.8, 20.0], [84.8, 20.5]]]}},
        {"type": "Feature", "properties": {"name": "Subarnapur"}, "geometry": {"type": "Polygon", "coordinates": [[[83.5, 20.8], [84.0, 20.8], [84.0, 20.3], [83.5, 20.3], [83.5, 20.8]]]}},
    ]
};

// Simplified Indian states boundaries (for demonstration)
const indianStatesBounds = {
    "Odisha": [[17.78, 81.37], [22.57, 87.53]],
    "Andhra Pradesh": [[12.62, 77.05], [19.91, 84.76]],
    "Maharashtra": [[15.60, 72.66], [22.03, 80.89]],
    "Karnataka": [[11.59, 74.12], [18.45, 78.59]],
    "Tamil Nadu": [[8.07, 76.23], [13.56, 80.34]],
    "Kerala": [[8.18, 74.86], [12.79, 77.42]],
    "Gujarat": [[20.13, 68.16], [24.70, 74.47]],
    "Rajasthan": [[23.03, 69.49], [30.12, 78.27]],
    "Madhya Pradesh": [[21.08, 74.02], [26.87, 82.78]],
    "Uttar Pradesh": [[23.84, 77.08], [30.43, 84.63]],
    "Bihar": [[24.30, 83.32], [27.52, 88.12]],
    "West Bengal": [[21.77, 85.82], [27.23, 89.68]],
    "Jharkhand": [[21.95, 83.32], [25.34, 87.57]],
    "Chhattisgarh": [[17.76, 80.27], [24.10, 84.40]],
    "Assam": [[24.13, 89.70], [28.22, 96.02]],
    "Telangana": [[15.75, 77.03], [19.95, 81.32]],
    "Punjab": [[29.53, 74.40], [32.51, 76.88]],
    "Haryana": [[27.66, 74.47], [30.93, 77.36]],
    "Himachal Pradesh": [[30.22, 75.49], [33.23, 79.04]],
    "Uttarakhand": [[28.43, 77.58], [31.45, 81.03]],
    "Goa": [[14.90, 73.67], [15.80, 74.67]],
    "Tripura": [[22.94, 91.10], [24.54, 92.67]],
    "Meghalaya": [[25.01, 89.84], [26.12, 92.81]],
    "Manipur": [[23.84, 93.03], [25.68, 94.78]],
    "Mizoram": [[21.97, 92.16], [24.62, 93.26]],
    "Nagaland": [[25.21, 93.33], [27.04, 95.16]],
    "Arunachal Pradesh": [[26.63, 91.51], [29.48, 97.42]],
    "Sikkim": [[27.05, 88.00], [28.13, 88.94]],
    "Delhi": [[28.40, 76.84], [28.88, 77.35]],
    "Jammu & Kashmir": [[32.27, 73.03], [37.12, 80.13]],
    "Ladakh": [[32.50, 75.89], [36.00, 79.86]]
};

// Global variables
let map;
let odishaLayer;
let currentHighlight;

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing application...');
    
    // Wait a bit for Leaflet to be fully loaded
    setTimeout(() => {
        initializeMap();
        populateStateDropdown();
        setupEventListeners();
        createLegend();
        console.log('Application initialized successfully');
    }, 100);
});

// Initialize Leaflet map
function initializeMap() {
    console.log('Initializing map...');
    
    map = L.map('map').setView([20.95, 84.80], 6);
    
    // Add OpenStreetMap tile layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
    
    // Add Odisha districts layer
    addOdishaLayer();
    
    console.log('Map initialized successfully');
}

// Add Odisha districts to the map
function addOdishaLayer() {
    console.log('Adding Odisha districts layer...');
    
    odishaLayer = L.geoJSON(odishaDistricts, {
        style: function(feature) {
            const districtName = feature.properties.name;
            const category = getDistrictCategory(districtName);
            return {
                fillColor: fraData[category]?.color || '#cccccc',
                weight: 2,
                opacity: 1,
                color: '#ffffff',
                dashArray: '',
                fillOpacity: 0.7
            };
        },
        onEachFeature: function(feature, layer) {
            const districtName = feature.properties.name;
            const category = getDistrictCategory(districtName);
            
            // Create popup content
            const popupContent = `
                <div style="font-family: var(--font-family-base); padding: 8px;">
                    <h4 style="margin: 0 0 8px 0; color: var(--color-primary);">${districtName} District</h4>
                    <p style="margin: 4px 0;"><strong>Category:</strong> ${category}</p>
                    <p style="margin: 4px 0;"><strong>CFR Potential:</strong> ${fraData[category]?.cfrPotential || 'N/A'}</p>
                    <p style="margin: 4px 0; font-size: 12px;">${fraData[category]?.description || 'No description available.'}</p>
                </div>
            `;
            
            // Bind popup
            layer.bindPopup(popupContent);
            
            // Click event for detailed modal
            layer.on('click', function(e) {
                console.log(`Clicked on ${districtName}`);
                showDistrictModal(districtName, category);
                // Prevent event propagation
                L.DomEvent.stopPropagation(e);
            });
            
            // Hover effects
            layer.on('mouseover', function(e) {
                const hoverLayer = e.target;
                hoverLayer.setStyle({
                    weight: 3,
                    color: '#333',
                    fillOpacity: 0.9
                });
                
                // Show tooltip
                const tooltip = `
                    <div style="font-size: 12px; font-weight: bold;">${districtName}</div>
                    <div style="font-size: 11px;">${category}</div>
                    <div style="font-size: 11px;">CFR: ${fraData[category]?.cfrPotential || 'N/A'}</div>
                `;
                
                hoverLayer.bindTooltip(tooltip, {
                    permanent: false,
                    sticky: true,
                    className: 'leaflet-tooltip-custom'
                }).openTooltip();
            });
            
            layer.on('mouseout', function(e) {
                odishaLayer.resetStyle(e.target);
                e.target.closeTooltip();
            });
        }
    }).addTo(map);
    
    console.log('Odisha districts layer added successfully');
}

// Get district category from FRA data
function getDistrictCategory(districtName) {
    for (const [category, data] of Object.entries(fraData)) {
        if (data.districts.includes(districtName)) {
            return category;
        }
    }
    return 'Unknown';
}

// Populate state dropdown
function populateStateDropdown() {
    console.log('Populating state dropdown...');
    
    const dropdown = document.getElementById('state-selector');
    if (!dropdown) {
        console.error('State selector dropdown not found');
        return;
    }
    
    indianStates.forEach(state => {
        const option = document.createElement('option');
        option.value = state;
        option.textContent = state;
        dropdown.appendChild(option);
    });
    
    console.log('State dropdown populated successfully');
}

// Set up event listeners
function setupEventListeners() {
    console.log('Setting up event listeners...');
    
    // State dropdown change
    const stateSelector = document.getElementById('state-selector');
    if (stateSelector) {
        stateSelector.addEventListener('change', function(e) {
            const selectedState = e.target.value;
            console.log(`Selected state: ${selectedState}`);
            if (selectedState) {
                zoomToState(selectedState);
            }
        });
        console.log('State selector event listener added');
    } else {
        console.error('State selector not found');
    }
    
    // Reset view button
    const resetBtn = document.getElementById('reset-view');
    if (resetBtn) {
        resetBtn.addEventListener('click', function(e) {
            console.log('Reset view button clicked');
            e.preventDefault();
            resetMapView();
        });
        console.log('Reset button event listener added');
    } else {
        console.error('Reset button not found');
    }
    
    // Legend toggle
    const legendToggle = document.getElementById('legend-toggle');
    if (legendToggle) {
        legendToggle.addEventListener('click', function(e) {
            console.log('Legend toggle clicked');
            e.preventDefault();
            toggleLegend();
        });
        console.log('Legend toggle event listener added');
    } else {
        console.error('Legend toggle not found');
    }
    
    // Modal close
    const modalClose = document.getElementById('modal-close');
    if (modalClose) {
        modalClose.addEventListener('click', function(e) {
            console.log('Modal close button clicked');
            e.preventDefault();
            closeModal();
        });
        console.log('Modal close event listener added');
    }
    
    // Close modal on background click
    const modal = document.getElementById('district-modal');
    if (modal) {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                console.log('Modal background clicked');
                closeModal();
            }
        });
        console.log('Modal background click event listener added');
    }
    
    console.log('All event listeners set up successfully');
}

// Zoom to selected state
function zoomToState(stateName) {
    console.log(`Zooming to state: ${stateName}`);
    
    // Remove previous highlight
    if (currentHighlight) {
        map.removeLayer(currentHighlight);
        currentHighlight = null;
    }
    
    const bounds = indianStatesBounds[stateName];
    if (bounds) {
        // Create highlight rectangle
        currentHighlight = L.rectangle(bounds, {
            color: '#e74c3c',
            weight: 3,
            fillOpacity: 0.1,
            dashArray: '10, 5'
        }).addTo(map);
        
        // Fit map to bounds with animation
        map.fitBounds(bounds, { 
            padding: [20, 20],
            animate: true,
            duration: 1.0
        });
        
        // Special handling for Odisha to show districts
        if (stateName === 'Odisha') {
            setTimeout(() => {
                map.fitBounds(odishaLayer.getBounds(), { 
                    padding: [20, 20],
                    animate: true,
                    duration: 0.5
                });
            }, 800);
        }
        
        console.log(`Successfully zoomed to ${stateName}`);
    } else {
        console.log(`Bounds not found for ${stateName}`);
    }
}

// Reset map view
function resetMapView() {
    console.log('Resetting map view...');
    
    // Remove highlight
    if (currentHighlight) {
        map.removeLayer(currentHighlight);
        currentHighlight = null;
    }
    
    // Reset dropdown
    const dropdown = document.getElementById('state-selector');
    if (dropdown) {
        dropdown.value = '';
    }
    
    // Reset map view to India with animation
    map.setView([20.95, 84.80], 6, {
        animate: true,
        duration: 1.0
    });
    
    console.log('Map view reset successfully');
}

// Create legend
function createLegend() {
    console.log('Creating legend...');
    
    const legendContent = document.getElementById('legend-content');
    if (!legendContent) {
        console.error('Legend content container not found');
        return;
    }
    
    legendContent.innerHTML = ''; // Clear existing content
    
    Object.entries(fraData).forEach(([category, data]) => {
        const legendItem = document.createElement('div');
        legendItem.className = 'legend-item';
        
        legendItem.innerHTML = `
            <div class="legend-color" style="background-color: ${data.color}"></div>
            <div class="legend-text">
                <div class="legend-label">${category}</div>
                <div class="legend-description">${data.cfrPotential} CFR potential</div>
            </div>
        `;
        
        legendContent.appendChild(legendItem);
    });
    
    console.log('Legend created successfully');
}

// Toggle legend visibility
function toggleLegend() {
    console.log('Toggling legend...');
    
    const content = document.getElementById('legend-content');
    const toggle = document.getElementById('legend-toggle');
    
    if (!content || !toggle) {
        console.error('Legend elements not found');
        return;
    }
    
    if (content.classList.contains('collapsed')) {
        content.classList.remove('collapsed');
        toggle.textContent = '−';
        console.log('Legend expanded');
    } else {
        content.classList.add('collapsed');
        toggle.textContent = '+';
        console.log('Legend collapsed');
    }
}

// Show district modal
function showDistrictModal(districtName, category) {
    console.log(`Showing modal for ${districtName}`);
    
    const modal = document.getElementById('district-modal');
    const modalTitle = document.getElementById('modal-title');
    const modalContent = document.getElementById('modal-content-body');
    
    if (!modal || !modalTitle || !modalContent) {
        console.error('Modal elements not found');
        return;
    }
    
    const categoryData = fraData[category] || {};
    
    modalTitle.textContent = `${districtName} District`;
    
    modalContent.innerHTML = `
        <div class="district-info">
            <h4>FRA Classification</h4>
            <div class="fra-potential" style="background-color: ${categoryData.color}20; color: ${categoryData.color}; border: 1px solid ${categoryData.color}40;">
                ${category}
            </div>
            <p><strong>CFR Potential:</strong> ${categoryData.cfrPotential || 'N/A'}</p>
            <p><strong>Description:</strong> ${categoryData.description || 'No description available.'}</p>
        </div>
        
        <div class="district-info">
            <h4>Forest Rights Act Information</h4>
            <p><strong>IFR:</strong> Individual Forest Rights - Rights over forest land for habitation and cultivation</p>
            <p><strong>CFR:</strong> Community Forest Rights - Rights to protect, regenerate, conserve or manage community forest resources</p>
            <p><strong>CR:</strong> Community Rights - Rights over minor forest produce, grazing, fishing</p>
        </div>
    `;
    
    modal.classList.remove('hidden');
    console.log('Modal displayed successfully');
}

// Close modal
function closeModal() {
    console.log('Closing modal...');
    
    const modal = document.getElementById('district-modal');
    if (modal) {
        modal.classList.add('hidden');
        console.log('Modal closed successfully');
    } else {
        console.error('Modal not found');
    }
}